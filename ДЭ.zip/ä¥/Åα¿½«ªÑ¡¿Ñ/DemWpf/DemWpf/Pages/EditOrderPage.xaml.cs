﻿using DemWpf.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemWpf.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditOrderPage.xaml
    /// </summary>
    public partial class EditOrderPage : Page
    {
        private Frame _frame;
        private OrderedProduct _orderedProduct;
        private Dem21Context db = new Dem21Context();

        public EditOrderPage(Frame frame, int orderId)
        {
            InitializeComponent();

            _frame = frame;

            if (orderId != 0)
            {
                LoadOrder(orderId);
                Title = "Редактирование заказа товаров";
            }
            else
            {
                _orderedProduct = new OrderedProduct();
                Title = "Добавление заказа товаров";
            }
        }

        private void LoadOrder(int orderId) 
        {
            try
            {
                _orderedProduct = db.OrderedProducts
               .Include(o => o.Order)
               .ThenInclude(o => o.PickUpPoint)
               .Include(o => o.Product)
               .First(x => x.OrderId == orderId);
                ArticleBox.Text = _orderedProduct.Product.Article;
                StatusBox.Text = _orderedProduct.Order.Status;
                AddressBox.Text = _orderedProduct.Order.PickUpPoint.Address;
                OrderDateBox.SelectedDate = _orderedProduct.Order.OrderDate;
                DeliveryDateBox.SelectedDate = _orderedProduct.Order.DeliveryDate;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказа. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }        
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _frame.GoBack();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _orderedProduct.Product.Article = ArticleBox.Text;
                _orderedProduct.Order.Status = StatusBox.Text;
                _orderedProduct.Order.PickUpPoint.Address = AddressBox.Text;
                _orderedProduct.Order.OrderDate = OrderDateBox.SelectedDate.Value;
                _orderedProduct.Order.DeliveryDate = DeliveryDateBox.SelectedDate.Value;

                db.OrderedProducts.Update(_orderedProduct);
                db.SaveChanges();
                _frame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                db.OrderedProducts.Remove(_orderedProduct);
                db.SaveChanges();
                _frame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);          
            }        
        }
    }
}
