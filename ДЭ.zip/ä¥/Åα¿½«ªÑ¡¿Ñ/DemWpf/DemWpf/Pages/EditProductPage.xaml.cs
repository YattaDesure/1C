﻿using DemWpf.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client.Extensions.Msal;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace DemWpf.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditProductPage.xaml
    /// </summary>
    public partial class EditProductPage : Page
    {
        private Frame _frame;
        private Product _product;
        private string _newImagePath;
        private Dem21Context db = new Dem21Context();

        public EditProductPage(Frame frame, int productId)
        {
            InitializeComponent();

            _frame = frame;

            if (productId != 0) 
            {
                LoadProduct(productId);
                Title = "Редактирование карточки товара";
            }
            else
            {
                _product = new Product();
                Title = "Добавление карточки товара";
            }
        }

        private void LoadLists()
        {
            CategotyBox.ItemsSource = db.Categories.ToList();
            ManufactuterBox.ItemsSource = db.Manufacturers.ToList();
            SupplierBox.ItemsSource = db.Suppliers.ToList();
        }

        private void LoadProduct(int productId) 
        {
            try
            {
                _product = db.Products
                .First(x => x.ProductId == productId);

                ArticleBox.Text = _product.Article;
                NameBox.Text = _product.Name;
                DescriptionBox.Text = _product.Description;
                PriceBox.Text = _product.Price.ToString();
                UnitBox.Text = _product.Unit;
                DiscountBox.Text = _product.Discount.ToString();
                AmountBox.Text = _product.Amount.ToString();

                CategotyBox.SelectedItem = _product.Category;
                ManufactuterBox.SelectedItem = _product.Manufacturer;
                SupplierBox.SelectedItem = _product.Supplier;

                ProductImage.Source = new BitmapImage(new Uri(_product.PhotoPath));
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки товара. {ex.Message}" , "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }          
        }

        private void SelectImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "Image|*.png;*.jpg";

            if (dialog.ShowDialog() != true)
                return;

            var image = new BitmapImage(new Uri(dialog.FileName));

            if (image.PixelHeight > 200 || image.PixelWidth > 300)
            {
                MessageBox.Show("Максимальный размер изображения - 300х200 пикселей", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var folder = Path.Combine(Environment.CurrentDirectory, "Images");
            Directory.CreateDirectory(folder);

            _newImagePath = Path.Combine(folder, Path.GetFileName(dialog.FileName));
            File.Copy(dialog.FileName, _newImagePath, true);
            ProductImage.Source = image;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            _frame.GoBack();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _product.Article = ArticleBox.Text;
                _product.Name = NameBox.Text;
                _product.Description = DescriptionBox.Text;
                _product.Price = decimal.Parse(PriceBox.Text);
                if (_product.Price < 0)
                    return;
                _product.Unit = UnitBox.Text;
                _product.Amount = int.Parse(AmountBox.Text);
                if (_product.Amount < 0)
                    return;
                _product.Discount = int.Parse(DiscountBox.Text);
                if (_product.Discount < 0)
                    return;
                _product.Supplier = SupplierBox.SelectedItem as Supplier;
                _product.Category = CategotyBox.SelectedItem as Category;
                _product.Manufacturer = ManufactuterBox.SelectedItem as Manufacturer;

                if (!String.IsNullOrWhiteSpace(_newImagePath))
                {
                    _product.Photo = Path.GetFileName(_newImagePath);
                }

                db.Products.Update(_product);
                db.SaveChanges();

                _frame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }           
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool isOrdered = db.OrderedProducts.Any(p => p.ProductId == _product.ProductId);
                if (isOrdered)
                {
                    MessageBox.Show("Нельзя удалить заказанный товар",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                db.Products.Remove(_product);
                db.SaveChanges();
                _frame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }          
        }
    }
}
