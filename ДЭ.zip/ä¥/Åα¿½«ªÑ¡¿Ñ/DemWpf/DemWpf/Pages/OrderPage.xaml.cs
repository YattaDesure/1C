﻿using DemWpf.Models;
using Microsoft.EntityFrameworkCore;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DemWpf.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        private User _currentUser;
        private Frame _frame;

        private List<OrderedProduct> _orderedProducts;
        public OrderPage(Frame frame, User user)
        {
            InitializeComponent();

            _frame = frame;
            _currentUser = user;

            _frame.Navigated += Frame_Navigated;
            LoadOrder();
        }

        private void Frame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            LoadOrder();
        }

        private void LoadOrder()
        {
            try
            {
                using var db = new Dem21Context();

                _orderedProducts = db.OrderedProducts
                    .Include(o => o.Order)
                    .ThenInclude(o => o.PickUpPoint)
                    .Include(o => o.Product)
                    .ToList();

                OrderListView.ItemsSource = _orderedProducts;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить заказы. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }                
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            _frame.GoBack();
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new EditOrderPage(_frame, 0));
        }

        private void OrderListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if ((_currentUser.Role.Name == "Администратор" ||
                _currentUser.Role.Name == "Менеджер") &&
                OrderListView.SelectedItem is OrderedProduct orderedProduct)
                {

                    _frame.Navigate(new EditOrderPage(_frame, orderedProduct.OrderId));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось получить выбранный заказ. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }        
        }
    }
}
