﻿using DemWpf.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemWpf.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        private Frame _frame;
        private User _currentUser;

        private List<Product> _products;
        public ProductPage(Frame frame, User user)
        {
            InitializeComponent();
            

            _frame = frame;
            _currentUser = user;

            _frame.Navigated += Frame_Navigated;

            LoadUser();
            LoadProducts();
            LoadSuppliers();

            SupplierFilterBox.SelectedIndex = 0;
            SortBox.SelectedIndex = 0;
        }

        private void Frame_Navigated(object sender, NavigationEventArgs e)
        {
            LoadProducts();
            FilterChanged(null, null);
        }

        private void LoadUser()
        {
            try
            {
                UserNameText.Text = _currentUser == null
                ? "Гость"
                : _currentUser.FullName;

                if (_currentUser != null && (_currentUser.Role.Name == "Администратор" ||
                   _currentUser.Role.Name == "Менеджер"))
                {
                    AddProduct.Visibility = Visibility.Visible;
                    OrderButton.Visibility = Visibility.Visible;
                    FilterStackPanel.Visibility = Visibility.Visible;
                }
                else
                {
                    AddProduct.Visibility = Visibility.Collapsed;
                    OrderButton.Visibility = Visibility.Collapsed;
                    FilterStackPanel.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось определить роль пользователя. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadProducts()
        {
            try
            {
                using var db = new Dem21Context();

                _products = db.Products
                    .Include(x => x.Manufacturer)
                    .Include(x => x.Supplier)
                    .Include(x => x.Category).ToList();

                ProductListView.ItemsSource = _products;
            }
            catch (Exception ex)
            {

                MessageBox.Show($"Не удалось загрузить продукты. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }        
        }

        private void LoadSuppliers()
        {
            try
            {
                using var db = new Dem21Context();
                SupplierFilterBox.Items.Clear();
                SupplierFilterBox.Items.Add("Все поставщики");

                var suppliers = db.Suppliers.Select(x => x.Name);

                foreach (var supplier in suppliers)
                {
                    SupplierFilterBox.Items.Add(supplier);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить поставщиков. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }   
        }

        private void FilterChanged(object sender, EventArgs e)
        {
            try
            {
                IEnumerable<Product> result = _products;

                string search = SearchTextBox.Text;

                if (!string.IsNullOrWhiteSpace(search))
                {
                    result = result.Where(p =>
                        p.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.Description.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.Manufacturer.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.Supplier.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.Category.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        p.Article.Contains(search, StringComparison.OrdinalIgnoreCase));
                }

                if (SupplierFilterBox.SelectedIndex > 0)
                {
                    string supplier = SupplierFilterBox.SelectedItem.ToString();
                    result = result.Where(p => p.Supplier.Name == supplier);
                }

                switch (SortBox.SelectedIndex)
                {
                    case 1:
                        result = result.OrderBy(p => p.Amount);
                        break;
                    case 2:
                        result = result.OrderByDescending(p => p.Amount);
                        break;
                }

                ProductListView.ItemsSource = result.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось применить фильтры. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ProductListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (_currentUser != null &&
               _currentUser.Role.Name == "Администратор" &&
                ProductListView.SelectedItem is Product product)
                {
                    _frame.Navigate(new EditProductPage(_frame, product.ProductId));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось выбрать продукт. {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            _frame.GoBack();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new EditProductPage(_frame, 0));
        }

        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new OrderPage(_frame, _currentUser));
        }
    }
}
